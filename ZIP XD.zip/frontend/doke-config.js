﻿// Doke - Configurações rápidas (edite aqui)
window.DOKE_CONFIG = window.DOKE_CONFIG || {
  
  // Debug (mostra toasts de erros globais)
  debug: false,
// WhatsApp do suporte (exemplo):
  // whatsappSupport: "https://wa.me/5599999999999?text=Oi%20Doke!%20Preciso%20de%20ajuda.",
  whatsappSupport: "",

  // Email de suporte (exemplo):
  // supportEmail: "suporte@seudominio.com",
  supportEmail: "",

  // Chat interno (página)
  supportChatUrl: "mensagens.html"
};


