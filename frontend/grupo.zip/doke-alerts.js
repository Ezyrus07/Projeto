(()=>{ 
  if(window.__dokeAlertsPatched) return;
  window.__dokeAlertsPatched = true;

  const nativeAlert = window.alert ? window.alert.bind(window) : (msg)=>console.log(msg);

  function classify(msg){
    const m = String(msg ?? '').trim();
    const low = m.toLowerCase();

    const has = (re)=> re.test(low);

    if(m.includes('✅') || m.includes('✓') || has(/sucesso|enviado|salvo|publicad|copiad|feito|conclu/)) return 'sucesso';
    if(m.includes('⚠') || has(/aten[cç][aã]o|aviso|obrigat|preench|selecione|verifique|falt/)) return 'aviso';
    if(m.includes('❌') || m.includes('×') || has(/erro|falha|inv[aá]lido|negad|cr[ií]tic|n[aã]o foi poss[ií]vel|indispon[ií]vel/)) return 'erro';
    return 'info';
  }

  function showToast(message, tipo){
    const msg = String(message ?? '');
    // 1) Toast padrão do projeto (script.js)
    if(typeof window.mostrarToast === 'function'){
      const t = (tipo==='sucesso') ? 'sucesso' : (tipo==='erro') ? 'erro' : 'aviso';
      window.mostrarToast(msg, t);
      return true;
    }
    // 2) dokeToast (stack no canto)
    if(typeof window.dokeToast === 'function'){
      const map = {sucesso:'success', erro:'error', aviso:'warn', info:'info'};
      const title = (tipo==='erro')?'Erro':(tipo==='sucesso')?'Feito!':(tipo==='aviso')?'Atenção':'Info';
      window.dokeToast({type: map[tipo] || 'info', title, message: msg});
      return true;
    }
    return false;
  }

  // Override do alert() para virar notificação com CSS
  window.alert = function(msg){
    try{
      const tipo = classify(msg);
      if(showToast(msg, tipo)) return;
    }catch(e){}
    return nativeAlert(msg);
  };

  // Helper público: window.dokeNotify("mensagem","sucesso|erro|aviso|info")
  window.dokeNotify = function(message, tipo='info'){
    try{
      if(showToast(message, tipo)) return;
    }catch(e){}
    return nativeAlert(message);
  };

  // Offline/Online
  function handleNet(){
    if(!navigator.onLine){
      showToast('Sem conexão. Algumas ações podem falhar até voltar a internet.', 'aviso');
      document.documentElement.classList.add('doke-offline');
    }else{
      document.documentElement.classList.remove('doke-offline');
    }
  }
  window.addEventListener('offline', handleNet);
  window.addEventListener('online', ()=>{ showToast('Conexão restaurada ✅', 'sucesso'); handleNet(); });
  handleNet();

  // Melhorias em mensagens inline (sem mudar sua lógica):
  // - Se existir #msg.msg, aplica estilo e tipo baseado no texto
  function enhanceInline(el){
    if(!el || el.__dokeEnhanced) return;
    el.__dokeEnhanced = true;
    el.classList.add('doke-inline');
    const txt = (el.textContent || '').toLowerCase();
    if(/erro|inv[aá]lido|falha|negad/.test(txt)) el.classList.add('doke-inline--erro');
    else if(/sucesso|feito|enviado|salvo|ok/.test(txt)) el.classList.add('doke-inline--sucesso');
    else if(txt.trim()) el.classList.add('doke-inline--info');
  }

  function scan(){
    // #msg, .msg, .alert, .message, etc
    document.querySelectorAll('#msg, .msg, .alert, .alerta, .message, .mensagem, .status-msg, .error, .erro, .success, .sucesso').forEach(enhanceInline);
  }

  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', scan);
  else scan();

  // Observa alterações pra pegar mensagens que aparecem depois (ex: login/cadastro)
  const mo = new MutationObserver((mutList)=>{
    for(const m of mutList){
      for(const node of m.addedNodes){
        if(!(node instanceof HTMLElement)) continue;
        if(node.matches && (node.matches('#msg, .msg, .alert, .alerta, .message, .mensagem, .status-msg'))) enhanceInline(node);
        node.querySelectorAll && node.querySelectorAll('#msg, .msg, .alert, .alerta, .message, .mensagem, .status-msg').forEach(enhanceInline);
      }
    }
  });
  try{ mo.observe(document.body, {childList:true, subtree:true}); }catch(e){}

})();