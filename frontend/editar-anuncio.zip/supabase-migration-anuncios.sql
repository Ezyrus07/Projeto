-- ==========================================================
-- DOKE - Supabase migration (tabela anuncios)
-- Objetivo: permitir salvar TODOS os campos do anunciar.html
-- ==========================================================

-- Dica: se sua tabela nao for public.anuncios, ajuste o schema/nome.

ALTER TABLE public.anuncios
  ADD COLUMN IF NOT EXISTS categoria TEXT,
  ADD COLUMN IF NOT EXISTS tipoPreco TEXT,
  ADD COLUMN IF NOT EXISTS tags JSONB,
  ADD COLUMN IF NOT EXISTS experiencia TEXT,
  ADD COLUMN IF NOT EXISTS prazo TEXT,
  ADD COLUMN IF NOT EXISTS garantia TEXT,
  ADD COLUMN IF NOT EXISTS politicaCancelamento TEXT,
  ADD COLUMN IF NOT EXISTS atendeEmergencia BOOLEAN DEFAULT FALSE,
  ADD COLUMN IF NOT EXISTS pagamentosAceitos JSONB,
  ADD COLUMN IF NOT EXISTS agenda JSONB,
  ADD COLUMN IF NOT EXISTS diplomaUrl TEXT;
