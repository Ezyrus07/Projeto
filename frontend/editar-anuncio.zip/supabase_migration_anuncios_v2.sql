-- Rode este SQL no Supabase (SQL Editor) para o editar anúncio salvar/carregar todos os campos do anunciar.html

alter table public.anuncios
  add column if not exists tags jsonb,
  add column if not exists experiencia text,
  add column if not exists prazo text,
  add column if not exists garantia text,
  add column if not exists politicaCancelamento text,
  add column if not exists atendeEmergencia boolean default false,
  add column if not exists pagamentosAceitos jsonb,
  add column if not exists agenda jsonb,
  add column if not exists diplomaUrl text,
  add column if not exists ativo boolean default true,
  add column if not exists updatedAt timestamptz;
