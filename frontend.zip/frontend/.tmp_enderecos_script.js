﻿// arquivo temporario neutralizado
(() => {})();
